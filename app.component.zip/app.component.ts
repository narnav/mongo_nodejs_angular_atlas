import { Component } from '@angular/core';
import { NotesService } from './notes.service';
import { Note } from './Note';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  all:Note[]=[];
  myNote:Note;
  constructor(private ns: NotesService){
  //get all notes
    this.ns.readAll().subscribe((result: any) => {
      this.all = result;
      console.log(this.all)
    })

//add note
    this.ns.addSingleNote({title: "test", content: "test content",_id:''}).subscribe((result: any) => {
      this.myNote = result;
      console.log(this.myNote)
    })

  }
  show(id:string){
    console.log(id)
     this.ns.deleteSingleStudent(id).subscribe((result: any) => {
       console.log(result)
      })

  }
}
