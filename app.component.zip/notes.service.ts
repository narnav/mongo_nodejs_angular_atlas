import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Note } from './note';

//import { Todo } from './../models/todo';
//import { Note } from './note';
//https://www.techiediaries.com/angular-10-crud-example-web-api/

const baseURL = 'http://localhost:3005/students';
const myServer = "http://localhost:3000/api/students/2";
// const httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });


@Injectable({
  providedIn: 'root'
})
export class NotesService {
  constructor(private httpClient: HttpClient) { }

  //get All - my server
  readAll(): Observable<Note[]> {
    return this.httpClient.get<Note[]>(baseURL)//, { headers: httpHeaders });
  }
  //get All - fake server
  readAllTodos(): Observable<Note> {
    return this.httpClient.get<Note>(baseURL);
  }

  //get Single
  readSingleNote(id: number): Observable<Note> {
    return this.httpClient.get<Note>(baseURL + "/" + id);
  }

  //Post Add Single
  addSingleNote( newNote: Note): Observable<Note> {
    return this.httpClient.post<Note>(baseURL , newNote);
  }

  //delete Single Note
  deleteSingleStudent(id: string): Observable<any> {
    return this.httpClient.delete<any>(baseURL + "/" + id);
  }

  // put - Update Single Note
  updateSingleNote(id: number, updNote: Note): Observable<Note> {
    return this.httpClient.put<Note>(baseURL + "/" + id, updNote);
  }

  //Test
  test(): string {
    return "user service working";
  }

}
